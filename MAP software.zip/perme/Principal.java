//Nombre:       Principal.java
//Proyecto:
//Autor:        Candi Gonz�lez Buesa
//Creacion:     29 Febrero 2004
//Ult modif:    04 Abril 2005
//Descripci�n:  Ventana principal de la aplicacion

import java.awt.*;
import java.io.FileReader;
import java.io.BufferedReader;
import java.awt.event.*;
import javax.swing.*;


import java.text.DecimalFormat;
import java.util.Enumeration;
import java.util.Vector;

public class Principal extends JFrame {

   static final int RESPIRACION_NULA = 1;
   static final int RESPIRACION_CONSTANTE = 2;

   int parametros = RESPIRACION_NULA;
   
   Vector unidadesS;
   Vector unidadesPOX;
   Vector unidadesPC;
   Vector unidadesW;
   Vector unidadesV;
   Vector unidadesT;
   Vector unidadesTH;
   Vector unidadesROX;
   Vector unidadesRC;
   
   Unidades unidades;

   JTextField campoH = new JTextField();
   JTextField campoS = new JTextField();
   JTextField campoIA = new JTextField();
   JTextField campoPOX = new JTextField();
   JTextField campoPC = new JTextField();
   JTextField campoW = new JTextField();
   JTextField campoV = new JTextField();
   JTextField campoT = new JTextField();
   JTextField campoOX = new JTextField();
   JTextField campoC = new JTextField();
   JTextField campoTH = new JTextField();
   JTextField campoROX = new JTextField();
   JTextField campoRC = new JTextField();
   JTextField campoTLIM = new JTextField();
   JTextField campoPlastico = new JTextField();
   JTextField campoFruta = new JTextField();
   
   JComboBox comboS;
   JComboBox comboPOX;
   JComboBox comboPC;
   JComboBox comboW;
   JComboBox comboV;
   JComboBox comboT;
   JComboBox comboTH;
   JComboBox comboROX;
   JComboBox comboRC;
   

   JLabel jLabel1 = new JLabel();
   JLabel jLabel2 = new JLabel();
   JLabel jLabel3 = new JLabel();
   JLabel jLabel4 = new JLabel();
   JLabel jLabel5 = new JLabel();
   JLabel jLabel6 = new JLabel();
   JLabel jLabel7 = new JLabel();
   JLabel jLabel8 = new JLabel();
   JLabel jLabel9 = new JLabel();
   JLabel jLabel10 = new JLabel();
   JLabel jLabel11 = new JLabel();
   JLabel jLabel12 = new JLabel();
   JLabel jLabel13 = new JLabel();
   JLabel jLabel14 = new JLabel();
   JLabel jLabel15 = new JLabel();
   JLabel jLabel16 = new JLabel();
   JLabel titulo1 = new JLabel();
   JLabel titulo2 = new JLabel();
   JLabel titulo3 = new JLabel();
   JLabel titulo4 = new JLabel();
   JLabel titulo5 = new JLabel();
   JLabel jLabelOX = new JLabel();
   JLabel jLabelC = new JLabel();
   JLabel logo = new JLabel();
   

   JButton botonSalir = new JButton();
   JButton botonCalcular = new JButton();
   JTextArea resultados = new JTextArea();
   JTextArea comentarios = new JTextArea();
   JScrollPane resultados2 = new JScrollPane();
   JScrollPane comentarios2 = new JScrollPane();
   JMenuBar jMenuBar1 = new JMenuBar();
   JMenu menuArchivo = new JMenu();
   JMenu menuEditar = new JMenu();
   JMenu menuParametros = new JMenu();
   JMenu menuAyuda = new JMenu();
   ButtonGroup group = new ButtonGroup();
   JRadioButtonMenuItem jRadio1;
   JRadioButtonMenuItem jRadio2;
   JMenuItem menuCargar = new JMenuItem();
   JMenuItem menuGuardar = new JMenuItem();
   JMenuItem menuSalir = new JMenuItem();
   JMenuItem menuCopiarTodo = new JMenuItem();
   JMenuItem menuCopiar = new JMenuItem();
   JMenuItem menuPlastico = new JMenuItem();
   JMenuItem menuFruta = new JMenuItem();
   JMenuItem menuUnidades = new JMenuItem();
   JMenuItem menuAcerca = new JMenuItem();
   
   private javax.swing.JFileChooser fileChooser = null;

   // Construimos el frame
   public Principal() {
      enableEvents(AWTEvent.WINDOW_EVENT_MASK);
      try {
         jbInit();
      } catch (Exception e) {
		JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		e.printStackTrace();
      }
   }

   // Inicializamos las componentes
   private void jbInit() throws Exception {
      
   	unidades = new Unidades(this);
   	
      this.setResizable(false);
      this.getContentPane().setLayout(null);
      this.setSize(new Dimension(755, 600));
      this.setTitle("Calculo permeabilidades v1.5");

      // inicializamos las etiquetas
      jLabel1.setText("H");
      jLabel1.setBounds(new Rectangle(10, 30, 30, 20));
      jLabel2.setText("ia");
      jLabel2.setBounds(new Rectangle(10, 60, 30, 20));
      jLabel3.setText("S");
      jLabel3.setBounds(new Rectangle(10, 90, 30, 20));
      jLabel4.setText("POX");
      jLabel4.setBounds(new Rectangle(10, 120, 30, 20));
      jLabel5.setText("PC");
      jLabel5.setBounds(new Rectangle(10, 150, 30, 20));
      jLabel6.setText("W");
      jLabel6.setBounds(new Rectangle(10, 180, 30, 20));
      jLabel7.setText("V");
      jLabel7.setBounds(new Rectangle(10, 210, 30, 20));
      jLabel8.setText("T");
      jLabel8.setBounds(new Rectangle(10, 240, 30, 20));
      jLabel9.setText("OX");
      jLabel9.setBounds(new Rectangle(10, 270, 30, 20));
      jLabel10.setText("C");
      jLabel10.setBounds(new Rectangle(10, 300, 30, 20));
      jLabel11.setText("TH");
      jLabel11.setBounds(new Rectangle(10, 330, 30, 20));
      jLabel12.setText("ROX");
      jLabel12.setBounds(new Rectangle(10, 360, 30, 20));    
      jLabel12.setEnabled(false);
      jLabel13.setText("RC");
      jLabel13.setBounds(new Rectangle(10, 390, 30, 20));
      jLabel13.setEnabled(false);
      jLabel14.setText("T lim");
      jLabel14.setBounds(new Rectangle(10, 420, 30, 20));
      jLabel15.setText("Plastico");
      jLabel15.setBounds(new Rectangle(10, 450, 60, 20));
      jLabel16.setText("Fruta");
      jLabel16.setBounds(new Rectangle(10, 480, 60, 20));
      
      
      titulo1.setText("Tiempo");
      titulo1.setBounds(new Rectangle(270, 20, 60, 20));
      titulo2.setText("Moles O2");
      titulo2.setBounds(new Rectangle(350, 20, 60, 20));
      titulo3.setText("Moles CO2");
      titulo3.setBounds(new Rectangle(440, 20, 60, 20));
      titulo4.setText("Incremento O2");
      titulo4.setBounds(new Rectangle(520, 20, 90, 20));
      titulo5.setText("Incremento CO2");
      titulo5.setBounds(new Rectangle(610, 20, 90, 20));
      

      this.getContentPane().add(jLabel1, null);
      this.getContentPane().add(jLabel2, null);
      this.getContentPane().add(jLabel3, null);
      this.getContentPane().add(jLabel4, null);
      this.getContentPane().add(jLabel5, null);
      this.getContentPane().add(jLabel6, null);
      this.getContentPane().add(jLabel7, null);
      this.getContentPane().add(jLabel8, null);
      this.getContentPane().add(jLabel9, null);
      this.getContentPane().add(jLabel10, null);
      this.getContentPane().add(jLabel11, null);
      this.getContentPane().add(jLabel12, null);
      this.getContentPane().add(jLabel13, null);
      this.getContentPane().add(jLabel14, null);
      this.getContentPane().add(jLabel15, null);
      this.getContentPane().add(jLabel16, null);
      this.getContentPane().add(titulo1, null);
      this.getContentPane().add(titulo2, null);
      this.getContentPane().add(titulo3, null);
      this.getContentPane().add(titulo4, null);
      this.getContentPane().add(titulo5, null);

      // inicializamos los campos de las variables
      campoH.setBounds(new Rectangle(40, 30, 70, 20));
      campoH.setText(String.valueOf(0.01F));
      campoIA.setBounds(new Rectangle(40, 60, 70, 20));
      campoIA.setText(String.valueOf(0));
      campoS.setBounds(new Rectangle(40, 90, 70, 20));
      campoS.setText(String.valueOf(0.003739F));
      campoPOX.setBounds(new Rectangle(40, 120, 70, 20));
      campoPOX.setText(String.valueOf(370));
      campoPOX.setEnabled(false);
      campoPC.setBounds(new Rectangle(40, 150, 70, 20));
      campoPC.setText(String.valueOf(1708));
      campoPC.setEnabled(false);
      campoW.setBounds(new Rectangle(40, 180, 70, 20));
      campoW.setText(String.valueOf(0));
      campoV.setBounds(new Rectangle(40, 210, 70, 20));
      campoV.setText(String.valueOf(132));
      campoT.setBounds(new Rectangle(40, 240, 70, 20));
      campoT.setText(String.valueOf(0));
      campoOX.setBounds(new Rectangle(40, 270, 70, 20));
      campoOX.setText(String.valueOf(2));
      campoC.setBounds(new Rectangle(40, 300, 70, 20));
      campoC.setText(String.valueOf(5));
      campoTH.setBounds(new Rectangle(40, 330, 70, 20));
      campoTH.setText(String.valueOf(0.98F));
      campoROX.setBounds(new Rectangle(40, 360, 70, 20));
      campoROX.setText(String.valueOf(1.0F/1.75F));
      campoROX.setEnabled(false);
      campoROX.setEditable(false);
      campoRC.setBounds(new Rectangle(40, 390, 70, 20));
      campoRC.setText(String.valueOf(1.0F/1.75F));
      campoRC.setEnabled(false);
      campoRC.setEditable(false);
      campoTLIM.setBounds(new Rectangle(40, 420, 70, 20));
      campoTLIM.setText(String.valueOf(100.0F));
      campoPlastico.setBounds(new Rectangle(60, 450, 100, 20));
      campoPlastico.setText("");
      campoPlastico.setEnabled(false);
      campoFruta.setBounds(new Rectangle(60, 480, 100, 20));
      campoFruta.setText("");
      campoFruta.setEnabled(false);
      
      this.getContentPane().add(campoH, null);
      this.getContentPane().add(campoIA, null);
      this.getContentPane().add(campoS, null);
      this.getContentPane().add(campoPOX, null);
      this.getContentPane().add(campoPC, null);
      this.getContentPane().add(campoW, null);
      this.getContentPane().add(campoV, null);
      this.getContentPane().add(campoT, null);
      this.getContentPane().add(campoOX, null);
      this.getContentPane().add(campoC, null);
      this.getContentPane().add(campoTH, null);
      this.getContentPane().add(campoROX, null);
      this.getContentPane().add(campoRC, null);
      this.getContentPane().add(campoTLIM, null);
      this.getContentPane().add(campoPlastico, null);
      this.getContentPane().add(campoFruta, null);

      
      // inicializamos las unidades

      // TODO: el "2"
      
      inicializarVectoresUnidades();
      
     // inicializamos los comboboxes

      GrupoUnidades grupo = (GrupoUnidades) unidades.unidades.get("S");
      comboS = new JComboBox(unidadesS);
      comboS.setBounds(new Rectangle(110, 90, 110, 20));
      comboS.setSelectedItem(grupo.unidadBase);
      this.getContentPane().add(comboS, null);

      grupo = (GrupoUnidades) unidades.unidades.get("POX");
      comboPOX = new JComboBox(unidadesPOX);
      comboPOX.setBounds(new Rectangle(110, 120, 110, 20));
      comboPOX.setSelectedItem(grupo.unidadBase);
      comboPOX.setEnabled(false);
      this.getContentPane().add(comboPOX, null);      
      
      grupo = (GrupoUnidades) unidades.unidades.get("PC");
      comboPC = new JComboBox(unidadesPC);
      comboPC.setBounds(new Rectangle(110, 150, 110, 20));
      comboPC.setSelectedItem(grupo.unidadBase);
      comboPC.setEnabled(false);
      this.getContentPane().add(comboPC, null);
   
      grupo = (GrupoUnidades) unidades.unidades.get("W");
      comboW = new JComboBox(unidadesW);
      comboW.setBounds(new Rectangle(110, 180, 110, 20));
      comboW.setSelectedItem(grupo.unidadBase);
      this.getContentPane().add(comboW, null);

      grupo = (GrupoUnidades) unidades.unidades.get("V");
      comboV = new JComboBox(unidadesV);
      comboV.setBounds(new Rectangle(110, 210, 110, 20));
      comboV.setSelectedItem(grupo.unidadBase);
      this.getContentPane().add(comboV, null);
      
      grupo = (GrupoUnidades) unidades.unidades.get("T");
      comboT = new JComboBox(unidadesT);
      comboT.setBounds(new Rectangle(110, 240, 110, 20));
      comboT.setSelectedItem(grupo.unidadBase);
      this.getContentPane().add(comboT, null);

      jLabelOX.setText("%");
      jLabelOX.setBounds(new Rectangle(115, 270, 110, 20));
      this.getContentPane().add(jLabelOX, null);
      
      jLabelC.setText("%");
      jLabelC.setBounds(new Rectangle(115, 300, 110, 20));
      this.getContentPane().add(jLabelC, null);      
      
      grupo = (GrupoUnidades) unidades.unidades.get("TH");
      comboTH = new JComboBox(unidadesTH);
      comboTH.setBounds(new Rectangle(110, 330, 110, 20));
      comboTH.setSelectedItem(grupo.unidadBase);
      this.getContentPane().add(comboTH, null);

      grupo = (GrupoUnidades) unidades.unidades.get("ROX");
      comboROX = new JComboBox(unidadesROX);
      comboROX.setBounds(new Rectangle(110, 360, 110, 20));
      comboROX.setSelectedItem(grupo.unidadBase);
      comboROX.setEnabled(false);
      comboROX.setEditable(false);
      this.getContentPane().add(comboROX, null);

      grupo = (GrupoUnidades) unidades.unidades.get("RC");
      comboRC = new JComboBox(unidadesRC);
      comboRC.setBounds(new Rectangle(110, 390, 110, 20));
      comboRC.setSelectedItem(grupo.unidadBase);
      comboRC.setEnabled(false);
      comboRC.setEditable(false);
      this.getContentPane().add(comboRC, null);
      
      // inicializamos los botones de Calcular y de Salir
      botonCalcular.setText("Calcular");
      botonCalcular.setBounds(new Rectangle(635, 460, 100, 30));
      botonCalcular.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(ActionEvent e) {
            botonCalcular_actionPerformed(e);
         }
      });

      botonSalir.setText("Salir");
      botonSalir.setBounds(new Rectangle(635, 500, 100, 30));
      botonSalir.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(ActionEvent e) {
            botonSalir_actionPerformed(e);
         }
      });

      this.getContentPane().add(botonCalcular, null);
      this.getContentPane().add(botonSalir, null);

      
      // inicializamos el area de texto
      resultados2.setAutoscrolls(true);
      resultados2.setBounds(new Rectangle(220, 40, 520, 410));
      resultados2.setPreferredSize(new Dimension(400, 55));
      this.getContentPane().add(resultados2, null);
      
      resultados.setText("");
      resultados2.getViewport().add(resultados);

      // inicializamos el area de comentarios
      comentarios2.setAutoscrolls(true);
      comentarios2.setBounds(new Rectangle(220, 460, 400, 100));
      comentarios2.setPreferredSize(new Dimension(400, 55));
      this.getContentPane().add(comentarios2, null);
      
      comentarios.setText("");
      comentarios2.getViewport().add(comentarios);
      
      ImageIcon imageLogo = new ImageIcon("logoFrutas.JPG");
      logo = new JLabel(imageLogo);
      logo.setBounds(new Rectangle(10, 497, 150, 80));
      this.getContentPane().add(logo, null);
      
      // inicializamos el menu
      jMenuBar1.setBounds(0, 0, 755, 20);
      this.getContentPane().add(jMenuBar1, null);
      
      // menu Archivo
      menuArchivo.setText("Archivo");
      jMenuBar1.add(menuArchivo);
      
      menuCargar.setText("Cargar");
      menuCargar.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(ActionEvent e) {
            menuCargar_actionPerformed(e);
         }
      });

      menuGuardar.setText("Guardar");
      menuGuardar.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(ActionEvent e) {
            menuGuardar_actionPerformed(e);
         }
      });

      menuSalir.setText("Salir");
      menuSalir.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(ActionEvent e) {
            botonSalir_actionPerformed(e);
         }
      });

      menuArchivo.add(menuCargar);
      menuArchivo.add(menuGuardar);
      menuArchivo.addSeparator();
      menuArchivo.add(menuSalir);
      
      // menu Editar      
      menuEditar.setText("Editar");
      jMenuBar1.add(menuEditar);
      
      menuCopiarTodo.setText("Copiar todo");
      menuCopiarTodo.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(ActionEvent e) {
            menuCopiarTodo_actionPerformed(e);
         }
      });

      menuCopiar.setText("Copiar");
      menuCopiar.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(ActionEvent e) {
            menuCopiar_actionPerformed(e);
         }
      });

      menuEditar.add(menuCopiarTodo);
      menuEditar.add(menuCopiar);

      // menu Parametros      
      menuParametros.setText("Parametros");
      jMenuBar1.add(menuParametros);
      
      jRadio1 = new JRadioButtonMenuItem("Respiracion nula");
      jRadio1.setSelected(true);
      group.add(jRadio1);
      menuParametros.add(jRadio1);
      jRadio1.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(ActionEvent e) {
            respNula_actionPerformed(e);
         }
      });      

      jRadio2 = new JRadioButtonMenuItem("Respiracion constante");
      //jRadio2.setMnemonic(KeyEvent.VK_C);
      group.add(jRadio2);
      menuParametros.add(jRadio2);
      jRadio2.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(ActionEvent e) {
            respCte_actionPerformed(e);
         }
      });
      
      menuParametros.addSeparator();
      
      menuPlastico.setText("Pl�stico");
      menuParametros.add(menuPlastico);
      menuPlastico.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	new MenuPlastico(Principal.this);
        }
      });
      
      menuFruta.setText("Fruta");
      menuParametros.add(menuFruta);
      menuFruta.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	new MenuFruta(Principal.this);           
        }
      });
      
      menuParametros.addSeparator();
      
      menuUnidades.setText("Unidades");
      menuParametros.add(menuUnidades);
      menuUnidades.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	new MenuUnidades(Principal.this);
        }
      });      
      
      // ayuda      
      menuAyuda.setText("Ayuda");
      jMenuBar1.add(menuAyuda);     

      menuAcerca.setText("Acerca de...");
      menuAyuda.add(menuAcerca);
      menuAcerca.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	new MenuAcerca(Principal.this);
        }
      });      
      
   }
   public void actualizarVectoresUnidades() {
 
    GrupoUnidades grupo;
    Enumeration enum;
    String selected;
    
    grupo = (GrupoUnidades) unidades.unidades.get("S");
    enum = grupo.unidades.elements();
    selected = comboS.getSelectedItem().toString();
    comboS.removeAllItems();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	comboS.addItem(unidad.nombre);
    }
    comboS.setSelectedItem(selected);

    grupo = (GrupoUnidades) unidades.unidades.get("POX");
    enum = grupo.unidades.elements();
    selected = comboPOX.getSelectedItem().toString();
    comboPOX.removeAllItems();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	comboPOX.addItem(unidad.nombre);
    }
    comboPOX.setSelectedItem(selected);

    grupo = (GrupoUnidades) unidades.unidades.get("PC");
    enum = grupo.unidades.elements();
    selected = comboPC.getSelectedItem().toString();
    comboPC.removeAllItems();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	comboPC.addItem(unidad.nombre);
    }  
    comboPC.setSelectedItem(selected);

    grupo = (GrupoUnidades) unidades.unidades.get("W");
    enum = grupo.unidades.elements();
    selected = comboW.getSelectedItem().toString();
    comboW.removeAllItems();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	comboW.addItem(unidad.nombre);
    }  
    comboW.setSelectedItem(selected);
    
    grupo = (GrupoUnidades) unidades.unidades.get("V");
    enum = grupo.unidades.elements();
    selected = comboV.getSelectedItem().toString();
    comboV.removeAllItems();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	comboV.addItem(unidad.nombre);
    }
    comboV.setSelectedItem(selected);

    grupo = (GrupoUnidades) unidades.unidades.get("T");
    enum = grupo.unidades.elements();
    selected = comboT.getSelectedItem().toString();
    comboT.removeAllItems();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	comboT.addItem(unidad.nombre);
    }  
    comboT.setSelectedItem(selected);

    grupo = (GrupoUnidades) unidades.unidades.get("TH");
    enum = grupo.unidades.elements();
    selected = comboTH.getSelectedItem().toString();
    comboTH.removeAllItems();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	comboTH.addItem(unidad.nombre);
    }  
    comboTH.setSelectedItem(selected);

    grupo = (GrupoUnidades) unidades.unidades.get("ROX");
    enum = grupo.unidades.elements();
    selected = comboROX.getSelectedItem().toString();
    comboROX.removeAllItems();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	comboROX.addItem(unidad.nombre);
    }  
    comboROX.setSelectedItem(selected);

    grupo = (GrupoUnidades) unidades.unidades.get("RC");
    enum = grupo.unidades.elements();
    selected = comboRC.getSelectedItem().toString();
    comboRC.removeAllItems();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	comboRC.addItem(unidad.nombre);
    }  
    comboRC.setSelectedItem(selected);

   }
   
   public void inicializarVectoresUnidades() {

    GrupoUnidades grupo;
    Enumeration enum;

    grupo = (GrupoUnidades) unidades.unidades.get("S");
    enum = grupo.unidades.elements();
    unidadesS = new Vector();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	unidadesS.add(unidad.nombre);
    } 

    grupo = (GrupoUnidades) unidades.unidades.get("POX");
    enum = grupo.unidades.elements();
    unidadesPOX = new Vector();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	unidadesPOX.add(unidad.nombre);
    }      

    grupo = (GrupoUnidades) unidades.unidades.get("PC");
    enum = grupo.unidades.elements();
    unidadesPC = new Vector();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	unidadesPC.add(unidad.nombre);
    }  
   

    grupo = (GrupoUnidades) unidades.unidades.get("W");
    enum = grupo.unidades.elements();
    unidadesW = new Vector();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	unidadesW.add(unidad.nombre);
    }  
    
    grupo = (GrupoUnidades) unidades.unidades.get("V");
    enum = grupo.unidades.elements();
    unidadesV = new Vector();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	unidadesV.add(unidad.nombre);
    }        

    grupo = (GrupoUnidades) unidades.unidades.get("T");
    enum = grupo.unidades.elements();
    unidadesT = new Vector();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	unidadesT.add(unidad.nombre);
    }  

    grupo = (GrupoUnidades) unidades.unidades.get("TH");
    enum = grupo.unidades.elements();
    unidadesTH = new Vector();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	unidadesTH.add(unidad.nombre);
    }  

    grupo = (GrupoUnidades) unidades.unidades.get("ROX");
    enum = grupo.unidades.elements();
    unidadesROX = new Vector();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	unidadesROX.add(unidad.nombre);
    }  

    grupo = (GrupoUnidades) unidades.unidades.get("RC");
    enum = grupo.unidades.elements();
    unidadesRC = new Vector();
    while (enum.hasMoreElements()) {
    	Unidad unidad = (Unidad) enum.nextElement();
    	unidadesRC.add(unidad.nombre);
    }  
    
  }

   protected void processWindowEvent(WindowEvent e) {
      super.processWindowEvent(e);
      if (e.getID() == WindowEvent.WINDOW_CLOSING) {
         System.exit(0);
      }
   }

   void respNula_actionPerformed(ActionEvent e) {
      parametros = RESPIRACION_NULA;
      campoROX.setEditable(false);
      campoRC.setEditable(false);
      jLabel12.setEnabled(false);
      jLabel13.setEnabled(false);
   }

   void respCte_actionPerformed(ActionEvent e) {
      parametros = RESPIRACION_CONSTANTE;
      campoROX.setEditable(true);
      campoRC.setEditable(true);
      jLabel12.setEnabled(true);
      jLabel13.setEnabled(true);
   }

   void menuCargar_actionPerformed(ActionEvent e) {

      // Si no existe el file chooser, crea uno
      if (fileChooser == null) {
         fileChooser = new javax.swing.JFileChooser();
         fileChooser.setDialogTitle("Open");
      }

      // Valor que retorna al elegir una opcion en el file chooser              
         
      int retVal = fileChooser.showOpenDialog(this);
         
     
       
      // Si se escogio Ok, (o abrir)
      if (retVal == javax.swing.JFileChooser.APPROVE_OPTION)
      {
         // El path absoluto del archivo elegido
         String fileName = fileChooser.getSelectedFile().getAbsolutePath();
         try
         {
            //Pasa el nombre del archivo a URL
            java.net.URL url = fileChooser.getSelectedFile().toURL();
              
            //VisualizaArchivo(url.getFile());
            FileReader archivo = new FileReader(fileName); 
            BufferedReader lector = new BufferedReader (archivo);
             
            String unaLinea = lector.readLine();
            StringBuffer losComentarios = new StringBuffer("");
            
            while (! unaLinea.equals("----------")) {
               losComentarios.append(unaLinea + "\n");
               unaLinea = lector.readLine();
            }
            
            unaLinea = lector.readLine();
            parametros = Integer.valueOf(unaLinea).intValue();

            unaLinea = lector.readLine();
            float H = Float.valueOf(unaLinea).floatValue();               
            unaLinea = lector.readLine();
            float IA = Float.valueOf(unaLinea).floatValue();               
            unaLinea = lector.readLine();
            float S = Float.valueOf(unaLinea).floatValue();
            unaLinea = lector.readLine();
            float POX = Float.valueOf(unaLinea).floatValue();               
            unaLinea = lector.readLine();
            float PC = Float.valueOf(unaLinea).floatValue();               
            unaLinea = lector.readLine();
            float W = Float.valueOf(unaLinea).floatValue();
            unaLinea = lector.readLine();
            float V = Float.valueOf(unaLinea).floatValue();               
            unaLinea = lector.readLine();
            float T = Float.valueOf(unaLinea).floatValue();               
            unaLinea = lector.readLine();
            float OX = Float.valueOf(unaLinea).floatValue();
            unaLinea = lector.readLine();
            float C = Float.valueOf(unaLinea).floatValue();               
            unaLinea = lector.readLine();
            float TH = Float.valueOf(unaLinea).floatValue();               
            unaLinea = lector.readLine();
            float ROX = Float.valueOf(unaLinea).floatValue();
            unaLinea = lector.readLine();
            float RC = Float.valueOf(unaLinea).floatValue();               
            unaLinea = lector.readLine();
            float TLIM = Float.valueOf(unaLinea).floatValue();  
            unaLinea = lector.readLine();
            campoPlastico.setText(unaLinea);
            unaLinea = lector.readLine();
            campoFruta.setText(unaLinea);
            unaLinea = lector.readLine();
            comboS.setSelectedItem(unaLinea);
            unaLinea = lector.readLine();
            comboPOX.setSelectedItem(unaLinea);
            unaLinea = lector.readLine();
            comboPC.setSelectedItem(unaLinea);
            unaLinea = lector.readLine();
            comboW.setSelectedItem(unaLinea);
            unaLinea = lector.readLine();
            comboV.setSelectedItem(unaLinea);
            unaLinea = lector.readLine();
            comboT.setSelectedItem(unaLinea);
            unaLinea = lector.readLine();
            comboTH.setSelectedItem(unaLinea);
            unaLinea = lector.readLine();
            comboROX.setSelectedItem(unaLinea);
            unaLinea = lector.readLine();
            comboRC.setSelectedItem(unaLinea);

            campoH.setText(String.valueOf(H));
            campoIA.setText(String.valueOf(IA));
            campoS.setText(String.valueOf(S));
            campoPOX.setText(String.valueOf(POX));
            campoPC.setText(String.valueOf(PC));
            campoW.setText(String.valueOf(W));
            campoV.setText(String.valueOf(V));
            campoT.setText(String.valueOf(T));
            campoOX.setText(String.valueOf(OX));
            campoC.setText(String.valueOf(C));
            campoTH.setText(String.valueOf(TH));
            campoROX.setText(String.valueOf(ROX));
            campoRC.setText(String.valueOf(RC));
            campoTLIM.setText(String.valueOf(TLIM));
            
            comentarios.setText(losComentarios.toString());

            switch (parametros) {
               case RESPIRACION_NULA: 
                  //campoROX.setEnabled(false);               
                  //campoRC.setEnabled(false);
                  jLabel12.setEnabled(false); 
                  jLabel13.setEnabled(false);                
                  jRadio2.setSelected(false);
                  jRadio1.setSelected(true);
                  break;
               case RESPIRACION_CONSTANTE:
                  //campoROX.setEnabled(true);               
                  //campoRC.setEnabled(true);
                  jLabel12.setEnabled(true); 
                  jLabel13.setEnabled(true); 
                  jRadio1.setSelected(false);
                  jRadio2.setSelected(true);
                  break;                  
            }

         }
         catch (Exception ex)
         {
			JOptionPane.showMessageDialog(null, "Se ha producido un error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			ex.printStackTrace();
         }
      }
   }

   void menuGuardar_actionPerformed(ActionEvent e) {

      float H, IA, S, POX, PC, W, V, T, OX, C, TH, ROX, RC, TLIM;
      
      try
      {
         H = Float.parseFloat(campoH.getText());
         IA = Float.parseFloat(campoIA.getText());
         S = Float.parseFloat(campoS.getText());
         POX = Float.parseFloat(campoPOX.getText());
         PC = Float.parseFloat(campoPC.getText());
         W = Float.parseFloat(campoW.getText());
         V = Float.parseFloat(campoV.getText());
         T = Float.parseFloat(campoT.getText());
         OX = Float.parseFloat(campoOX.getText());
         C = Float.parseFloat(campoC.getText());
         TH = Float.parseFloat(campoTH.getText());
         ROX = Float.parseFloat(campoROX.getText());
         RC = Float.parseFloat(campoRC.getText());
         TLIM = Float.parseFloat(campoTLIM.getText());
      }
      catch (NumberFormatException ex)
      {
         //comentarios.setText("Datos incorrectamente introducidos");
         resultados.setText("");
         return;
      }
      
      // Utiliza un file chooser para explorar donde guardarlo
      // Si no existe, crea uno
      if (fileChooser == null)
      {
         fileChooser = new javax.swing.JFileChooser();
      }
      int retVal = fileChooser.showSaveDialog(this);
      if (retVal == javax.swing.JFileChooser.APPROVE_OPTION)
      {
         String fileName = fileChooser.getSelectedFile().getAbsolutePath();
         try
         {
            java.io.FileWriter fileWriter = new java.io.FileWriter(fileName);
            java.io.BufferedWriter br = new java.io.BufferedWriter(fileWriter);

            // pinta los comentarios, una raya separadora, el tipo de calculo, 
            // y los parametros

            StringBuffer text = new StringBuffer(comentarios.getText());
            text.append("\n----------\n");
            text.append(String.valueOf(parametros) + "\n");
            
            text.append(String.valueOf(H + "\n" + IA + "\n" + S + "\n" + 
                                       POX + "\n" + PC + "\n" + W + "\n" + 
                                       V + "\n" + T + "\n" + OX + "\n" + 
                                       C + "\n" + TH + "\n" + ROX + "\n" + 
                                       RC + "\n" + TLIM + "\n" + 
									   campoPlastico.getText() + "\n" + campoFruta.getText() + "\n" + 
									   comboS.getSelectedItem() + "\n" +
									   comboPOX.getSelectedItem() + "\n" +
									   comboPC.getSelectedItem() + "\n" + 
									   comboW.getSelectedItem() + "\n" + 
									   comboV.getSelectedItem() + "\n" + 
									   comboT.getSelectedItem() + "\n" + 
									   comboTH.getSelectedItem() + "\n" + 
									   comboROX.getSelectedItem() + "\n" + 
									   comboRC.getSelectedItem() + "\n"));
            
            br.write(text.toString().replaceAll("\n", "\r\n"));
            br.close();
           
         
         }
         catch (Exception ex)
         {
			JOptionPane.showMessageDialog(null, "Se ha producido un error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			ex.printStackTrace();
         }
      }

   }

   void menuCopiarTodo_actionPerformed (ActionEvent e) {
      resultados.selectAll();
      resultados.copy();
   }

   void menuCopiar_actionPerformed (ActionEvent e) {
      resultados.copy();
   }


   void botonCalcular_actionPerformed(ActionEvent e) {

      float H, IA, S, POX, PC, W, V, T, OX, C, TH, ROX, RC, TLIM;
      float factorS, factorPOX, factorPC, factorW, factorV, factorT, factorTH, factorROX, factorRC; 
      
      GrupoUnidades grupo = (GrupoUnidades) unidades.unidades.get("S");
      Unidad unidad = (Unidad) grupo.unidades.get(comboS.getSelectedItem());
      if (unidad.factor != 0){
      	factorS = 1/unidad.factor;
      } else {
      	factorS = 1;
      }

      grupo = (GrupoUnidades) unidades.unidades.get("POX");
      unidad = (Unidad) grupo.unidades.get(comboPOX.getSelectedItem());
      if (unidad.factor != 0){
      	factorPOX = 1/unidad.factor;
      } else {
      	factorPOX = 1;
      }

      grupo = (GrupoUnidades) unidades.unidades.get("PC");
      unidad = (Unidad) grupo.unidades.get(comboPC.getSelectedItem());
      if (unidad.factor != 0){
      	factorPC = 1/unidad.factor;
      } else {
      	factorPC = 1;
      }

      grupo = (GrupoUnidades) unidades.unidades.get("W");
      unidad = (Unidad) grupo.unidades.get(comboW.getSelectedItem());
      if (unidad.factor != 0){
      	factorW = 1/unidad.factor;
      } else {
      	factorW = 1;
      }

      grupo = (GrupoUnidades) unidades.unidades.get("V");
      unidad = (Unidad) grupo.unidades.get(comboV.getSelectedItem());
      if (unidad.factor != 0){
      	factorV = 1/unidad.factor;
      } else {
      	factorV = 1;
      }
 
      grupo = (GrupoUnidades) unidades.unidades.get("T");
      unidad = (Unidad) grupo.unidades.get(comboT.getSelectedItem());
      if (unidad.factor != 0){
      	factorT = 1/unidad.factor;
      } else {
      	factorT = 1;
      }
      
      grupo = (GrupoUnidades) unidades.unidades.get("TH");
      unidad = (Unidad) grupo.unidades.get(comboTH.getSelectedItem());
      if (unidad.factor != 0){
      	factorTH = 1/unidad.factor;
      } else {
      	factorTH = 1;
      }
      
      grupo = (GrupoUnidades) unidades.unidades.get("ROX");
      unidad = (Unidad) grupo.unidades.get(comboROX.getSelectedItem());
      if (unidad.factor != 0){
      	factorROX = 1/unidad.factor;
      } else {
      	factorROX = 1;
      }
 
      grupo = (GrupoUnidades) unidades.unidades.get("RC");
      unidad = (Unidad) grupo.unidades.get(comboRC.getSelectedItem());
      if (unidad.factor != 0){
      	factorRC = 1/unidad.factor;
      } else {
      	factorRC = 1;
      }
            
      try
      {
         H = Float.parseFloat(campoH.getText());
         IA = Float.parseFloat(campoIA.getText());
         S = Float.parseFloat(campoS.getText())*factorS;
         POX = Float.parseFloat(campoPOX.getText())*factorPOX;
         PC = Float.parseFloat(campoPC.getText())*factorPC;
         W = Float.parseFloat(campoW.getText())*factorW;
         V = Float.parseFloat(campoV.getText())*factorV;
         T = Float.parseFloat(campoT.getText())*factorT;
         OX = Float.parseFloat(campoOX.getText());
         C = Float.parseFloat(campoC.getText());
         TH = Float.parseFloat(campoTH.getText())*factorTH;
         ROX = Float.parseFloat(campoROX.getText())*factorROX;
         RC = Float.parseFloat(campoRC.getText())*factorRC;
         TLIM = Float.parseFloat(campoTLIM.getText());
      }
      catch (NumberFormatException ex)
      {
         //comentarios.setText("Datos incorrectamente introducidos");
         resultados.setText("");
         return;
      }

      if (parametros == RESPIRACION_NULA) {
         
         // hacemos los calculos suponiendo respiracion nula == cere3.for
         // c�lculo de la evoluci�n de O2 y CO2 en la respiraci�n de cerezas en
         // medios permeables suponiendo ROX Y RC CEROS   
               
         float VOX1;
         float VOX2;
         float VOX3;
         float VOX4;
         float VC1;
         float VC2;
         float VC3;
         float VC4;
         float OX1;
         float OX2;
         float OX3;
         float C1;
         float C2;
         float C3;
         float VNAN;
         float DVOX;
         float DVC;
   
         resultados.setText("");
      
         do {
            do {
               VOX1 = 100 * (((S * POX * (0.21F - OX / 100)) / (V * TH)));
               VC1 = 100 * (((S * PC * (0 - C / 100)) / (V * TH)));
   
               T = T + H / 2;
               OX1 = OX + (H / 2) * VOX1;
               C1 = C + (H / 2) * VC1;
      
               VOX2 = 100 * (((S * POX * (0.21F - OX1 / 100)) / (V * TH)));
               VC2 = 100 * (((S * PC * (0 - C1 / 100)) / (V * TH)));
   
               OX2 = OX + (H / 2) * VOX2;
               C2 = C + (H / 2) * VC2;
   
               VOX3 = 100 * (((S * POX * (0.21F - OX2 / 100)) / (V * TH)));
               VC3 = 100 * (((S * PC * (0 - C2 / 100)) / (V * TH)));
   
               T = T + H / 2;
               OX3 = OX + H * VOX3;
               C3 = C + H * VC3;
   
               VOX4 = 100 * (((S * POX * (0.21F - OX3 / 100)) / (V * TH)));
               VC4 = 100 * (((S * PC * (0 - C3 / 100)) / (V * TH)));
   
               OX = OX + (H / 6) * (VOX1 + 2 * VOX2 + 2 * VOX3 + VOX4);
               C = C + (H / 6) * (VC1 + 2 * VC2 + 2 * VC3 + VC4);
   
               DVOX = 100 * (((S * POX * (0.21F - OX / 100)) / (V * TH)));
               DVC = 100 * (((S * PC * (0 - C / 100)) / (V * TH)));
               IA = IA + 1;
   
               VNAN = ((int) (IA / 50)) * 50;
            } while (VNAN != IA);
   
            java.util.Vector parameters = new java.util.Vector();
            parameters.add(new Float(T));
            parameters.add(new Float(OX));
            parameters.add(new Float(C));
            parameters.add(new Float(DVOX));
            parameters.add(new Float(DVC));
            
            DecimalFormat myFormatter1 = new DecimalFormat("0.0000");
            DecimalFormat myFormatter2 = new DecimalFormat("0.000000");
            
            String result = (("             " + myFormatter1.format(T)).substring(myFormatter1.format(T).length()) + 
            ("             " + myFormatter1.format(OX)).substring(myFormatter1.format(OX).length()) + 
            ("             " + myFormatter1.format(C)).substring(myFormatter1.format(C).length()) + 
            ("             " + myFormatter2.format(DVOX)).substring(myFormatter2.format(DVOX).length()) +
            ("             " + myFormatter2.format(DVC)).substring(myFormatter2.format(DVC).length()) + "\n").replace(',', '.'); 
   
            resultados.append(result);
                        
         }
         while (T < TLIM);
         
         this.validate();
      }
      
      else if (parametros == RESPIRACION_CONSTANTE) {
         
         // hacemos los calculos suponiendo respiracion constante  == cere1.for
         // c�lculo de la evoluci�n de O2 y CO2 en la respiraci�n de cerezas en
         // medios permeables con velocidad de respiracion constante
                 
         float VOX1;
         float VOX2;
         float VOX3;
         float VOX4;
         float VC1;
         float VC2;
         float VC3;
         float VC4;
         float OX1;
         float OX2;
         float OX3;
         float C1;
         float C2;
         float C3;
         float VNAN;
         float DVOX;
         float DVC;
   
         resultados.setText("");
      
         do {
            do {
               VOX1 = 100 * (((S * POX * (0.21F - OX / 100)) / (V * TH)) - (W / (V * ROX)));
               VC1 = 100 * (((S * PC * (0 - C / 100)) / (V * TH)) + (W / (V * RC)));
   
               T = T + H / 2;
               OX1 = OX + (H / 2) * VOX1;
               C1 = C + (H / 2) * VC1;
      
               VOX2 = 100 * (((S * POX * (0.21F - OX1 / 100)) / (V * TH)) - (W / (V * ROX)));
               VC2 = 100 * (((S * PC * (0 - C1 / 100)) / (V * TH)) + (W / (V * RC)));
   
               OX2 = OX + (H / 2) * VOX2;
               C2 = C + (H / 2) * VC2;
   
               VOX3 = 100 * (((S * POX * (0.21F - OX2 / 100)) / (V * TH)) - (W / (V * ROX)));
               VC3 = 100 * (((S * PC * (0 - C2 / 100)) / (V * TH)) + (W / (V * RC)));
   
               T = T + H / 2;
               OX3 = OX + H * VOX3;
               C3 = C + H * VC3;
   
               VOX4 = 100 * (((S * POX * (0.21F - OX3 / 100)) / (V * TH)) - (W / (V * ROX)));
               VC4 = 100 * (((S * PC * (0 - C3 / 100)) / (V * TH)) + (W / (V * RC)));
   
               OX = OX + (H / 6) * (VOX1 + 2 * VOX2 + 2 * VOX3 + VOX4);
               C = C + (H / 6) * (VC1 + 2 * VC2 + 2 * VC3 + VC4);
   
               DVOX = 100 * (((S * POX * (0.21F - OX / 100)) / (V * TH)) - (W / (V * ROX)));
               DVC = 100 * (((S * PC * (0 - C / 100)) / (V * TH)) + (W / (V * RC)));
               IA = IA + 1;
   
               VNAN = ((int) (IA / 2000)) * 2000;
            } while (VNAN != IA);
   
            java.util.Vector parameters = new java.util.Vector();
            parameters.add(new Float(T));
            parameters.add(new Float(OX));
            parameters.add(new Float(C));
            parameters.add(new Float(DVOX));
            parameters.add(new Float(DVC));
            
            DecimalFormat myFormatter1 = new DecimalFormat("0.0000");
            DecimalFormat myFormatter2 = new DecimalFormat("0.000000");
            
            String result = (("             " + myFormatter1.format(T)).substring(myFormatter1.format(T).length()) + 
            ("             " + myFormatter1.format(OX)).substring(myFormatter1.format(OX).length()) + 
            ("             " + myFormatter1.format(C)).substring(myFormatter1.format(C).length()) + 
            ("             " + myFormatter2.format(DVOX)).substring(myFormatter2.format(DVOX).length()) +
            ("             " + myFormatter2.format(DVC)).substring(myFormatter2.format(DVC).length()) + "\n").replace(',', '.'); 
   
            resultados.append(result);
                        
         }
         while ((T < TLIM) && (OX > 0.3F));
         
         this.validate();         
      }
      
   }
   
   
   void botonSalir_actionPerformed(ActionEvent e) {
      System.exit(0);
   }


}
