//Nombre:       MenuPlastico.java
//Proyecto:
//Autor:        Candi Gonz�lez Buesa
//Creacion:     11 Marzo 2005
//Ult modif:    01 Abril 2005
//Descripci�n:  Base de datos de plasticos

import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

public class MenuPlastico extends JFrame
{
   JTextField jtfNombre;
   JTextField jtfPOX;
   JTextField jtfPC;
   JComboBox comboPOX;
   JComboBox comboPC;   
   JButton jbGuardar;
   JButton jbCargar;
   JButton jbCancelar;
   JButton jbNuevo;
   Principal parent;
   JLabel jLabel;
   JList listaPlasticos;
   DefaultListModel modelPlasticos;
   Plastico plasticoSelected;
   int indexPlasticoSelected;
   FileInputStream ficheroEntrada;
   FileOutputStream ficheroSalida;
   File file;

   public MenuPlastico(Principal parent)
   {   

      this.parent = parent;
      
      this.setTitle("Base de Datos de pl�sticos");
      this.setResizable(false);      
      this.setLocation (parent.getLocation().x + 150, parent.getLocation().y + 50);
      this.getContentPane().setLayout(null);
      this.setSize (395, 170);
      
      modelPlasticos = new DefaultListModel();

      try {
        file = new File("plasticos.txt");
    
        // Create file if it does not exist
        boolean success = file.createNewFile();
        ficheroEntrada = new FileInputStream (file);
	  
		  String linea = leerLinea(ficheroEntrada);
		  
		  while (linea != "") {
		  	
		  	Plastico plastico = new Plastico();
		  	plastico.nombre = linea;
		  	plastico.POX = Float.parseFloat(leerLinea(ficheroEntrada));
		  	plastico.unidadPOX = leerLinea(ficheroEntrada);
		  	plastico.PC = Float.parseFloat(leerLinea(ficheroEntrada));
		  	plastico.unidadPC = leerLinea(ficheroEntrada);
		  	modelPlasticos.addElement(plastico);
		  	
		  	linea = leerLinea(ficheroEntrada);
		  
		  }
		  
		  ficheroEntrada.close();
      } catch (IOException e) {
		JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		e.printStackTrace();
      }	   
      plasticoSelected = null;
      indexPlasticoSelected = -1;
      listaPlasticos = new JList(modelPlasticos);
      listaPlasticos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      
		listaPlasticos.addMouseListener(new MouseAdapter (){
			  public void mouseClicked(MouseEvent e){
			     indexPlasticoSelected = listaPlasticos.locationToIndex(e.getPoint());
			     if (indexPlasticoSelected == -1) return;
			     plasticoSelected = (Plastico) modelPlasticos.getElementAt(indexPlasticoSelected);
			     jtfNombre.setText(plasticoSelected.nombre);
			     jtfPOX.setText(String.valueOf(plasticoSelected.POX));
			     comboPOX.setSelectedItem(plasticoSelected.unidadPOX);
			     jtfPC.setText(String.valueOf(plasticoSelected.PC));
			     comboPC.setSelectedItem(plasticoSelected.unidadPC);
			     jbGuardar.setEnabled(true);
			   }
			});
		
      JScrollPane scrollPane = new JScrollPane(listaPlasticos);	
      scrollPane.setBounds(new Rectangle(10, 10, 150, 80));
      this.getContentPane().add(scrollPane, null);
		
      jLabel = new JLabel("Nombre");
      jLabel.setBounds(new Rectangle(170, 10, 40, 20));
      this.getContentPane().add(jLabel, null);

      jLabel = new JLabel("POX");
      jLabel.setBounds(new Rectangle(170, 40, 40, 20));
      this.getContentPane().add(jLabel, null);      

      jLabel = new JLabel("PC");
      jLabel.setBounds(new Rectangle(170, 70, 40, 20));
      this.getContentPane().add(jLabel, null);  
      
      jtfNombre = new JTextField();
      jtfNombre.setBounds(new Rectangle(210, 10, 170, 20));
      this.getContentPane().add(jtfNombre, null);  
      
      jtfPOX = new JTextField();
      jtfPOX.setBounds(new Rectangle(210, 40, 70, 20));
      this.getContentPane().add(jtfPOX, null);  

      GrupoUnidades grupo = (GrupoUnidades) parent.unidades.unidades.get("POX");
      comboPOX = new JComboBox(parent.unidadesPOX);
      comboPOX.setBounds(new Rectangle(280, 40, 100, 20));
      comboPOX.setSelectedItem(grupo.unidadBase);
      this.getContentPane().add(comboPOX, null); 
      
      jtfPC = new JTextField();
      jtfPC.setBounds(new Rectangle(210, 70, 70, 20));
      this.getContentPane().add(jtfPC, null);  
      
      grupo = (GrupoUnidades) parent.unidades.unidades.get("PC");
      comboPC = new JComboBox(parent.unidadesPC);
      comboPC.setBounds(new Rectangle(280, 70, 100, 20));
      comboPC.setSelectedItem(grupo.unidadBase);
      this.getContentPane().add(comboPC, null); 
      
      jbCargar = new JButton ("Cargar");
      jbCargar.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
        	//
        	MenuPlastico.this.parent.campoPlastico.setText(MenuPlastico.this.jtfNombre.getText());
        	MenuPlastico.this.parent.campoPOX.setText(MenuPlastico.this.jtfPOX.getText());
        	MenuPlastico.this.parent.comboPOX.setSelectedItem(MenuPlastico.this.comboPOX.getSelectedItem());
        	MenuPlastico.this.parent.campoPC.setText(MenuPlastico.this.jtfPC.getText());
        	MenuPlastico.this.parent.comboPC.setSelectedItem(MenuPlastico.this.comboPC.getSelectedItem());
        	MenuPlastico.this.dispose();
        }
      });
      jbCargar.setBounds(new Rectangle(10, 100, 90, 30));
      this.getContentPane().add(jbCargar, null);       
      
      jbGuardar = new JButton ("Cambiar");
      jbGuardar.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
        	Plastico plastico = new Plastico();
        	plastico.nombre = MenuPlastico.this.jtfNombre.getText();
        	plastico.POX = Float.parseFloat(MenuPlastico.this.jtfPOX.getText());
        	plastico.unidadPOX = MenuPlastico.this.comboPOX.getSelectedItem().toString();
        	plastico.PC = Float.parseFloat(MenuPlastico.this.jtfPC.getText());
        	plastico.unidadPC = MenuPlastico.this.comboPC.getSelectedItem().toString();
        	modelPlasticos.removeElementAt(indexPlasticoSelected);
        	modelPlasticos.add(indexPlasticoSelected, plastico);
        	
        	try {
				ficheroSalida = new FileOutputStream (file);
				for (int i=0; i<modelPlasticos.size(); i++) {
					plastico = (Plastico) modelPlasticos.elementAt(i);
					ficheroSalida.write(plastico.nombre.concat("\r\n").getBytes());
					ficheroSalida.write(String.valueOf(plastico.POX).concat("\r\n").getBytes());
					ficheroSalida.write(String.valueOf(plastico.POX).concat("\r\n").getBytes());
					ficheroSalida.write(String.valueOf(plastico.PC).concat("\r\n").getBytes());
					ficheroSalida.write(String.valueOf(plastico.PC).concat("\r\n").getBytes());
					
				}
				ficheroSalida.close();
				
				
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
        }
      });
      jbGuardar.setBounds(new Rectangle(100, 100, 90, 30));
      jbGuardar.setEnabled(false);
      this.getContentPane().add(jbGuardar, null); 

      jbNuevo = new JButton ("Nuevo");
      jbNuevo.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
        	Plastico plastico;
        	try {
        		plastico = new Plastico();
        		plastico.nombre = MenuPlastico.this.jtfNombre.getText();
        		plastico.POX = Float.parseFloat(MenuPlastico.this.jtfPOX.getText());
        		plastico.unidadPOX = MenuPlastico.this.comboPOX.getSelectedItem().toString();
        		plastico.PC = Float.parseFloat(MenuPlastico.this.jtfPC.getText());
        		plastico.unidadPC = MenuPlastico.this.comboPC.getSelectedItem().toString();
        		modelPlasticos.addElement(plastico);
        	} catch (java.lang.NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();        	
        	}
        	try {
				ficheroSalida = new FileOutputStream (file);
				for (int i=0; i<modelPlasticos.size(); i++) {
					plastico = (Plastico) modelPlasticos.elementAt(i);
					ficheroSalida.write(plastico.nombre.concat("\r\n").getBytes());
					ficheroSalida.write(String.valueOf(plastico.POX).concat("\r\n").getBytes());
					ficheroSalida.write(plastico.unidadPOX.concat("\r\n").getBytes());
					ficheroSalida.write(String.valueOf(plastico.PC).concat("\r\n").getBytes());
					ficheroSalida.write(plastico.unidadPC.concat("\r\n").getBytes());
					
				}
				ficheroSalida.close();
				
				
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
        }
      });
      jbNuevo.setBounds(new Rectangle(190, 100, 90, 30));
      this.getContentPane().add(jbNuevo, null); 
      
      jbCancelar = new JButton ("Cerrar");
      jbCancelar.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
        	MenuPlastico.this.dispose();
        }
      });
      jbCancelar.setBounds(new Rectangle(280, 100, 90, 30));
      this.getContentPane().add(jbCancelar, null); 
      
      
      this.setVisible (true);
      
   }
   
   private String leerLinea (FileInputStream indice) {
	
	String linea = "";
	
	int iLetra;
	char cLetra;
	try {
		
		iLetra = indice.read();
		cLetra = (char) iLetra;
		while ((iLetra != -1) && (cLetra != '\n') && (cLetra != '\r')) {
			linea = linea + cLetra;
			iLetra = indice.read();
           	cLetra = (char) iLetra;
        }
		
		while ((iLetra != -1) && (cLetra != '\n')){
           	iLetra = indice.read();
           	cLetra = (char) iLetra;
        }
		
	} catch (IOException e) {
		JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		e.printStackTrace();
	}
	
	return linea;
}   
}

class Plastico {
	
	String nombre;
	float POX;
	String unidadPOX;
	float PC;
	String unidadPC;
	
	public Plastico () {
	}
	
	public String toString() {
		return nombre + " / POX: " + POX + ", PC: " + PC;
	}
	
}