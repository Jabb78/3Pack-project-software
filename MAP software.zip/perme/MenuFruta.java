//Nombre:       MenuFruta.java
//Proyecto:
//Autor:        Candi Gonz�lez Buesa
//Creacion:     11 Marzo 2005
//Ult modif:    01 Abril 2005
//Descripci�n:  Base de datos de frutas

import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

public class MenuFruta extends JFrame
{
   JTextField jtfNombre;
   JTextField jtfROX;
   JTextField jtfRC;
   JComboBox comboROX;
   JComboBox comboRC;
   JButton jbGuardar;
   JButton jbCargar;
   JButton jbCancelar;
   JButton jbNuevo;
   Principal parent;
   JLabel jLabel;
   JList listaFrutas;
   DefaultListModel modelFrutas;
   Fruta frutaSelected;
   int indexFrutaSelected;
   FileInputStream ficheroEntrada;
   FileOutputStream ficheroSalida;
   File file;

   public MenuFruta(Principal parent)
   {   

      this.parent = parent;
      
      this.setTitle("Base de Datos de pl�sticos");
      this.setResizable(false);      
      this.setLocation (parent.getLocation().x + 150, parent.getLocation().y + 50);
      this.getContentPane().setLayout(null);
      this.setSize (395, 170);
      
      modelFrutas = new DefaultListModel();

      try {
        file = new File("frutas.txt");
    
        // Create file if it does not exist
        boolean success = file.createNewFile();
        ficheroEntrada = new FileInputStream (file);
	  
		  String linea = leerLinea(ficheroEntrada);
		  
		  while (linea != "") {
		  	
		  	Fruta fruta = new Fruta();
		  	fruta.nombre = linea;
		  	fruta.ROX = Float.parseFloat(leerLinea(ficheroEntrada));
		  	fruta.unidadROX = leerLinea(ficheroEntrada);
		  	fruta.RC = Float.parseFloat(leerLinea(ficheroEntrada));
		  	fruta.unidadRC = leerLinea(ficheroEntrada);
		  	modelFrutas.addElement(fruta);
		  	
		  	linea = leerLinea(ficheroEntrada);
		  
		  }
		  
		  ficheroEntrada.close();
      } catch (IOException e) {
		JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		e.printStackTrace();
      }	   
      frutaSelected = null;
      indexFrutaSelected = -1;
      listaFrutas = new JList(modelFrutas);
      listaFrutas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      
		listaFrutas.addMouseListener(new MouseAdapter (){
			  public void mouseClicked(MouseEvent e){
			     indexFrutaSelected = listaFrutas.locationToIndex(e.getPoint());
			     if (indexFrutaSelected == -1) return;
			     frutaSelected = (Fruta) modelFrutas.getElementAt(indexFrutaSelected);
			     jtfNombre.setText(frutaSelected.nombre);
			     jtfROX.setText(String.valueOf(frutaSelected.ROX));
			     comboROX.setSelectedItem(frutaSelected.unidadROX);
			     jtfRC.setText(String.valueOf(frutaSelected.RC));
			     comboRC.setSelectedItem(frutaSelected.unidadRC);
			     jbGuardar.setEnabled(true);
			   }
			});
		
      JScrollPane scrollPane = new JScrollPane(listaFrutas);	
      scrollPane.setBounds(new Rectangle(10, 10, 150, 80));
      this.getContentPane().add(scrollPane, null);
		
      jLabel = new JLabel("Nombre");
      jLabel.setBounds(new Rectangle(170, 10, 40, 20));
      this.getContentPane().add(jLabel, null);

      jLabel = new JLabel("ROX");
      jLabel.setBounds(new Rectangle(170, 40, 40, 20));
      this.getContentPane().add(jLabel, null);      

      jLabel = new JLabel("RC");
      jLabel.setBounds(new Rectangle(170, 70, 40, 20));
      this.getContentPane().add(jLabel, null);  
      
      jtfNombre = new JTextField();
      jtfNombre.setBounds(new Rectangle(210, 10, 170, 20));
      this.getContentPane().add(jtfNombre, null);  
      
      jtfROX = new JTextField();
      jtfROX.setBounds(new Rectangle(210, 40, 70, 20));
      this.getContentPane().add(jtfROX, null);  
     
      GrupoUnidades grupo = (GrupoUnidades) parent.unidades.unidades.get("ROX");
      comboROX = new JComboBox(parent.unidadesROX);
      comboROX.setBounds(new Rectangle(280, 40, 100, 20));
      comboROX.setSelectedItem(grupo.unidadBase);
      this.getContentPane().add(comboROX, null);      
      
      jtfRC = new JTextField();
      jtfRC.setBounds(new Rectangle(210, 70, 70, 20));
      this.getContentPane().add(jtfRC, null);  

      grupo = (GrupoUnidades) parent.unidades.unidades.get("RC");
      comboRC = new JComboBox(parent.unidadesRC);
      comboRC.setBounds(new Rectangle(280, 70, 100, 20));
      comboRC.setSelectedItem(grupo.unidadBase);
      this.getContentPane().add(comboRC, null); 
      
      jbCargar = new JButton ("Cargar");
      jbCargar.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
        	//
        	MenuFruta.this.parent.campoFruta.setText(MenuFruta.this.jtfNombre.getText());
        	MenuFruta.this.parent.campoROX.setText(MenuFruta.this.jtfROX.getText());
        	MenuFruta.this.parent.comboROX.setSelectedItem(MenuFruta.this.comboROX.getSelectedItem());
        	MenuFruta.this.parent.campoRC.setText(MenuFruta.this.jtfRC.getText());
        	MenuFruta.this.parent.comboRC.setSelectedItem(MenuFruta.this.comboRC.getSelectedItem());
        	MenuFruta.this.dispose();
        }
      });
      jbCargar.setBounds(new Rectangle(10, 100, 90, 30));
      this.getContentPane().add(jbCargar, null);       
      
      jbGuardar = new JButton ("Cambiar");
      jbGuardar.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
        	Fruta fruta = new Fruta();
        	fruta.nombre = MenuFruta.this.jtfNombre.getText();
        	fruta.ROX = Float.parseFloat(MenuFruta.this.jtfROX.getText());
        	fruta.unidadROX = MenuFruta.this.comboROX.getSelectedItem().toString();
        	fruta.RC = Float.parseFloat(MenuFruta.this.jtfRC.getText());
        	fruta.unidadRC = MenuFruta.this.comboRC.getSelectedItem().toString();
        	modelFrutas.removeElementAt(indexFrutaSelected);
        	modelFrutas.add(indexFrutaSelected, fruta);
        	
        	try {
				ficheroSalida = new FileOutputStream (file);
				for (int i=0; i<modelFrutas.size(); i++) {
					fruta = (Fruta) modelFrutas.elementAt(i);
					ficheroSalida.write(fruta.nombre.concat("\r\n").getBytes());
					ficheroSalida.write(String.valueOf(fruta.ROX).concat("\r\n").getBytes());
					ficheroSalida.write(fruta.unidadROX.concat("\r\n").getBytes());
					ficheroSalida.write(String.valueOf(fruta.RC).concat("\r\n").getBytes());
					ficheroSalida.write(fruta.unidadRC.concat("\r\n").getBytes());
					
				}
				ficheroSalida.close();
				
				
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
        }
      });
      jbGuardar.setBounds(new Rectangle(100, 100, 90, 30));
      jbGuardar.setEnabled(false);
      this.getContentPane().add(jbGuardar, null); 

      jbNuevo = new JButton ("Nuevo");
      jbNuevo.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
        	Fruta fruta;
        	try {
        		fruta = new Fruta();
        		fruta.nombre = MenuFruta.this.jtfNombre.getText();
        		fruta.ROX = Float.parseFloat(MenuFruta.this.jtfROX.getText());
        		fruta.unidadROX = MenuFruta.this.comboROX.getSelectedItem().toString();
        		fruta.RC = Float.parseFloat(MenuFruta.this.jtfRC.getText());
        		fruta.unidadRC = MenuFruta.this.comboRC.getSelectedItem().toString();
        		modelFrutas.addElement(fruta);
        	} catch (java.lang.NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
        	}
        	try {
				ficheroSalida = new FileOutputStream (file);
				for (int i=0; i<modelFrutas.size(); i++) {
					fruta = (Fruta) modelFrutas.elementAt(i);
					ficheroSalida.write(fruta.nombre.concat("\r\n").getBytes());
					ficheroSalida.write(String.valueOf(fruta.ROX).concat("\r\n").getBytes());
					ficheroSalida.write(fruta.unidadROX.concat("\r\n").getBytes());
					ficheroSalida.write(String.valueOf(fruta.RC).concat("\r\n").getBytes());
					ficheroSalida.write(fruta.unidadRC.concat("\r\n").getBytes());
					
				}
				ficheroSalida.close();
				
				
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				e.printStackTrace();
			}
        }
      });
      jbNuevo.setBounds(new Rectangle(190, 100, 90, 30));
      this.getContentPane().add(jbNuevo, null); 
      
      jbCancelar = new JButton ("Cerrar");
      jbCancelar.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
        	MenuFruta.this.dispose();
        }
      });
      jbCancelar.setBounds(new Rectangle(280, 100, 90, 30));
      this.getContentPane().add(jbCancelar, null); 
      
      
      this.setVisible (true);
      
   }
   
   private String leerLinea (FileInputStream indice) {
	
	String linea = "";
	
	int iLetra;
	char cLetra;
	try {
		
		iLetra = indice.read();
		cLetra = (char) iLetra;
		while ((iLetra != -1) && (cLetra != '\n') && (cLetra != '\r')) {
			linea = linea + cLetra;
			iLetra = indice.read();
           	cLetra = (char) iLetra;
        }
		
		while ((iLetra != -1) && (cLetra != '\n')){
           	iLetra = indice.read();
           	cLetra = (char) iLetra;
        }
		
	} catch (IOException e) {
		JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		e.printStackTrace();
	}
	
	return linea;
}   
}

class Fruta {
	
	String nombre;
	float ROX;
	String unidadROX;
	float RC;
	String unidadRC;
	
	public Fruta () {
	}
	
	public String toString() {
		return nombre + " / ROX: " + ROX + ", RC: " + RC;
	}
	
}