//Nombre:       Unidad.java
//Proyecto:
//Autor:        Candi Gonz�lez Buesa
//Creacion:     25 Marzo 2005
//Ult modif:    25 Marzo 2005
//Descripci�n:  Estructura

class Unidad {
	
	String nombre;
	float factor;
	
	public Unidad () {
		
	}
	
	public Unidad (String nombre, float factor) {
		this.nombre = nombre;
		this.factor = factor;
	}
	
	public String toString() {
		return nombre + " / factor: " + factor;
	}
	
}