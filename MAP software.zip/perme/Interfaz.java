//Nombre:       Interfaz.java
//Proyecto:
//Autor:        Candi Gonz�lez Buesa
//Creacion:     29 Febrero 2004
//Ult modif:    29 Febrero 2004
//Descripci�n:  Main de la aplicacion

import javax.swing.JOptionPane;
import javax.swing.UIManager;


import java.awt.*;

public class Interfaz {
   boolean packFrame = false;
   Principal frame;

   // Construimos la aplicacion
   public Interfaz() {
      frame = new Principal();
      if (packFrame) {
         frame.pack();
      } else {
         frame.validate();
      }
      // Centramos la ventana
      Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
      Dimension frameSize = frame.getSize();
      if (frameSize.height > screenSize.height) {
         frameSize.height = screenSize.height;
      }
      if (frameSize.width > screenSize.width) {
         frameSize.width = screenSize.width;
      }
      frame.setLocation(
         (screenSize.width - frameSize.width) / 2,
         (screenSize.height - frameSize.height) / 2);
      frame.setVisible(true);
   }
   // Main
   public static void main(String[] args) {
      try {
         UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      } catch (Exception e) {
		JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		e.printStackTrace();
      }
      new Interfaz();
   }
}
