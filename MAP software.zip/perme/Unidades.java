//Nombre:       Unidades.java
//Proyecto:
//Autor:        Candi Gonz�lez Buesa
//Creacion:     25 Marzo 2005
//Ult modif:    25 Marzo 2005
//Descripci�n:  Estructura que almacena las unidades

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.swing.JOptionPane;

class Unidades {
	File file; 
	FileInputStream ficheroEntrada;
	FileOutputStream ficheroSalida;
	Principal parent;
	Hashtable unidades;
	 
	public Unidades(Principal parent) {
		this.parent = parent;
		
		// cargamos las unidades base
		unidades = new Hashtable();
		
		unidades.put("S", new GrupoUnidades("m2"));
		unidades.put("POX", new GrupoUnidades("mL mil / m2 h atm"));
		unidades.put("PC", new GrupoUnidades("mL mil / m2 h atm"));
		unidades.put("W", new GrupoUnidades("Kg"));
		unidades.put("V", new GrupoUnidades("mL"));
		unidades.put("T", new GrupoUnidades("h"));
		unidades.put("TH", new GrupoUnidades("mil pulg"));
		unidades.put("ROX", new GrupoUnidades("Kg h / mL"));
		unidades.put("RC", new GrupoUnidades("Kg h / mL"));

	      // cargamos en la estructura de unidades el fichero unidades.txt

	      // Create file if it does not exist
	      try {
	        file = new File("unidades.txt");
	        boolean success = file.createNewFile();
	        if (success) {
	        	// si el fichero no existia, se debe inicializar
	        	ficheroSalida = new FileOutputStream (file);
	        	String inicio = "S\r\nm2\r\n1\r\nPOX\r\nmL mil / m2 h atm\r\n1\r\nPC\r\n" +
				"mL mil / m2 h atm\r\n1\r\nW\r\nKg\r\n1\r\nV\r\nmL\r\n1\r\nT\r\n" +
				"h\r\n1\r\nTH\r\nmil pulg\r\n1\r\nROX\r\nKg h / mL\r\n1\r\nRC\r\nKg h / mL\r\n" +
				"1\r\n";
	        	ficheroSalida.write(inicio.getBytes());
				ficheroSalida.close();	        	
	        	
	        }
	        	ficheroEntrada = new FileInputStream (file);
		  
			  String linea = leerLinea(ficheroEntrada);
			  String tipoUnidad;
			  
			  while (linea != "") {
			  	
			  	Unidad unidad = new Unidad();
			  	tipoUnidad = linea;
			  	unidad.nombre = leerLinea(ficheroEntrada);
			  	unidad.factor = Float.parseFloat(leerLinea(ficheroEntrada));
			  	//this.parent.modelUnidades.addElement(unidad);
			  	nuevaUnidad(tipoUnidad, unidad);
			  	
			  	linea = leerLinea(ficheroEntrada);
			  
			  }
			  
			  ficheroEntrada.close();
	    } catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
	    }		
		
		
	}

	public void nuevaUnidad (String tipoUnidad, Unidad unidad) {
		GrupoUnidades grupo = (GrupoUnidades) unidades.get(tipoUnidad);
		grupo.unidades.put(unidad.nombre, unidad);	
	}
	
	public void guardarUnidades () {
	try {
		ficheroSalida = new FileOutputStream (file);
		Enumeration enum = unidades.elements();
		Enumeration claves = unidades.keys();
		while (enum.hasMoreElements()){
			GrupoUnidades grupo = (GrupoUnidades) enum.nextElement();
			String tipoUnidad = (String) claves.nextElement();
			Enumeration enum2 = grupo.unidades.elements();
			while (enum2.hasMoreElements()){
				Unidad unidad = (Unidad) enum2.nextElement();
				String cadenaUnidad = tipoUnidad + "\r\n" + unidad.nombre + "\r\n" + unidad.factor + "\r\n";
				ficheroSalida.write(cadenaUnidad.getBytes());
			}
		}
		ficheroSalida.close();

    } catch (IOException e) {
		JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		e.printStackTrace();
    }
	}

	private String leerLinea (FileInputStream indice) {
	
		String linea = "";
	
		int iLetra;
		char cLetra;
		try {
			
			iLetra = indice.read();
			cLetra = (char) iLetra;
			while ((iLetra != -1) && (cLetra != '\n') && (cLetra != '\r')) {
				linea = linea + cLetra;
				iLetra = indice.read();
				cLetra = (char) iLetra;
			}
		
			while ((iLetra != -1) && (cLetra != '\n')){
				iLetra = indice.read();
				cLetra = (char) iLetra;
			}
		
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Se ha producido un error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
	
		return linea;
	}   
}



