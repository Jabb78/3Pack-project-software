//Nombre:       MenuAcerca.java
//Proyecto:
//Autor:        Candi Gonz�lez Buesa
//Creacion:     11 Marzo 2005
//Ult modif:    04 Abril 2005
//Descripci�n:  Ventana "Acerca de..."

import java.awt.Rectangle;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class MenuAcerca extends JFrame
{

   public MenuAcerca(Principal parent)
   {   
      
      this.setTitle("Acerca de...");
      this.setResizable(false);      
      this.setLocation (parent.getLocation().x + 150, parent.getLocation().y + 50);
      this.getContentPane().setLayout(null);
      this.setSize (250, 100);
      
      JLabel jLabel = new JLabel("Version 1.6");
      jLabel.setBounds(new Rectangle(10, 10, 140, 20));
      this.getContentPane().add(jLabel, null); 
      
      jLabel = new JLabel("Contacto: gonzalez_buesa@yahoo.es");
      jLabel.setBounds(new Rectangle(10, 40, 220, 20));
      this.getContentPane().add(jLabel, null); 
      
      this.setVisible (true);
      
   }
   
}