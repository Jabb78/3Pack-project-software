//Nombre:       MenuUnidades.java
//Proyecto:
//Autor:        Candi Gonz�lez Buesa
//Creacion:     11 Marzo 2005
//Ult modif:    11 Marzo 2005
//Descripci�n:  Menu de administracion de unidades

import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Enumeration;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;


public class MenuUnidades extends JFrame
{
 JTextField jtfNombre;
 JTextField jtfFactor;
 JTextField jtfUnidadBase;
 JButton jbGuardar;
 JButton jbCambiar;
 JButton jbNuevo;
 Principal parent;
 JLabel jLabel;
 JList listaUnidades;
 DefaultListModel modelUnidades;
 Unidad unidadSelected;
 int indexUnidadSelected;
 Vector tipoUnidades;
 JComboBox comboTipoUnidades;

 

 public MenuUnidades(Principal parent)
 {   

    this.parent = parent;
    
    this.setTitle("Base de Datos de unidades");
    this.setResizable(false);      
    this.setLocation (parent.getLocation().x + 150, parent.getLocation().y + 50);
    this.getContentPane().setLayout(null);
    this.setSize (435, 170);
    
    modelUnidades = new DefaultListModel();
    
    tipoUnidades = new Vector();
    tipoUnidades.add("S");
    tipoUnidades.add("POX");
    tipoUnidades.add("PC");
    tipoUnidades.add("W");
    tipoUnidades.add("V");
    tipoUnidades.add("T");
    tipoUnidades.add("TH");
    tipoUnidades.add("ROX");
    tipoUnidades.add("RC");
    
    comboTipoUnidades = new JComboBox(tipoUnidades);
    comboTipoUnidades.setBounds(new Rectangle(10, 10, 150, 20));
    comboTipoUnidades.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
      	jtfFactor.setText("");
      	jtfNombre.setText("");
      	jtfUnidadBase.setText("");
      	seleccionarUnidad(comboTipoUnidades.getSelectedItem().toString());
       }
    });
    this.getContentPane().add(comboTipoUnidades, null);
    
    
    unidadSelected = null;
    indexUnidadSelected = -1;
    listaUnidades = new JList(modelUnidades);
    listaUnidades.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    
		listaUnidades.addMouseListener(new MouseAdapter (){
			  public void mouseClicked(MouseEvent e){
			     indexUnidadSelected = listaUnidades.locationToIndex(e.getPoint());
			     if (indexUnidadSelected == -1) return;
			     unidadSelected = (Unidad) modelUnidades.getElementAt(indexUnidadSelected);
			     jtfNombre.setText(unidadSelected.nombre);
			     jtfFactor.setText(String.valueOf(unidadSelected.factor));
			     jbGuardar.setEnabled(true);
			   }
			});
		
    JScrollPane scrollPane = new JScrollPane(listaUnidades);	
    scrollPane.setBounds(new Rectangle(10, 40, 150, 90));
    this.getContentPane().add(scrollPane, null);
		
    jLabel = new JLabel("Nombre");
    jLabel.setBounds(new Rectangle(170, 10, 80, 20));
    this.getContentPane().add(jLabel, null);

    jLabel = new JLabel("Factor");
    jLabel.setBounds(new Rectangle(170, 40, 80, 20));
    this.getContentPane().add(jLabel, null);      

    jLabel = new JLabel("Unidad base");
    jLabel.setBounds(new Rectangle(170, 70, 80, 20));
    this.getContentPane().add(jLabel, null);  
    
    jtfNombre = new JTextField();
    jtfNombre.setBounds(new Rectangle(260, 10, 150, 20));
    this.getContentPane().add(jtfNombre, null);  
    
    jtfFactor = new JTextField();
    jtfFactor.setBounds(new Rectangle(260, 40, 150, 20));
    this.getContentPane().add(jtfFactor, null);  
    
    jtfUnidadBase = new JTextField();
    jtfUnidadBase.setEditable(false);
    jtfUnidadBase.setBounds(new Rectangle(260, 70, 150, 20));
    this.getContentPane().add(jtfUnidadBase, null);  
    
    jbCambiar = new JButton ("Cambiar");
    jbCambiar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
      	cambiarUnidad (comboTipoUnidades.getSelectedItem().toString(), jtfNombre.getText(), jtfFactor.getText());
      }
 
    });
    jbCambiar.setBounds(new Rectangle(170, 100, 80, 30));
    jbCambiar.setEnabled(false);
    this.getContentPane().add(jbCambiar, null); 

    jbNuevo = new JButton ("Nuevo");
    jbNuevo.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
      		crearNuevaUnidad (comboTipoUnidades.getSelectedItem().toString(), jtfNombre.getText(), jtfFactor.getText());
      }
    });
    jbNuevo.setBounds(new Rectangle(250, 100, 80, 30));
    this.getContentPane().add(jbNuevo, null); 
    
    jbGuardar = new JButton ("Guardar");
    jbGuardar.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
      	guardarUnidades();
      }
    });
    jbGuardar.setBounds(new Rectangle(330, 100, 80, 30));
    this.getContentPane().add(jbGuardar, null); 
    
    this.setVisible (true);
    
    comboTipoUnidades.setSelectedItem("S");
    seleccionarUnidad("S");
 
 }
 
 public void seleccionarUnidad (String item) {
 	GrupoUnidades grupo = (GrupoUnidades) parent.unidades.unidades.get(item);
 	Enumeration enum = grupo.unidades.elements();
 	jtfUnidadBase.setText(grupo.unidadBase);
 	modelUnidades.clear();
    while (enum.hasMoreElements()) {
      	Unidad unidad = (Unidad) enum.nextElement();
      	modelUnidades.addElement(unidad);
      } 	
 
 }
 
 public void crearNuevaUnidad (String tipoUnidades, String nombre, String factor) {
 	Unidad unidad = new Unidad(nombre, Float.parseFloat(factor));
 	GrupoUnidades grupo = (GrupoUnidades) parent.unidades.unidades.get(tipoUnidades);
 	parent.unidades.unidades.remove(tipoUnidades);
 	grupo.unidades.put(nombre, unidad);
 	parent.unidades.unidades.put(tipoUnidades, grupo);
 	seleccionarUnidad(tipoUnidades);
 	parent.actualizarVectoresUnidades();
 }

 public void cambiarUnidad (String tipoUnidades, String nombre, String factor) {
 	Unidad unidad = new Unidad(nombre, Float.parseFloat(factor));
 	GrupoUnidades grupo = (GrupoUnidades) parent.unidades.unidades.get(tipoUnidades);
 	parent.unidades.unidades.remove(tipoUnidades);
 	grupo.unidades.remove(nombre);
 	grupo.unidades.put(nombre, unidad);
 	parent.unidades.unidades.put(tipoUnidades, grupo);
 	seleccionarUnidad(tipoUnidades);
 	parent.actualizarVectoresUnidades();
 }
 
 public void guardarUnidades() {
 	parent.unidades.guardarUnidades();
 	
 }
 
}
