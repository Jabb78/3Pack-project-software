//Nombre:       GrupoUnidades.java
//Proyecto:
//Autor:        Candi Gonz�lez Buesa
//Creacion:     25 Marzo 2005
//Ult modif:    25 Marzo 2005
//Descripci�n:  Estructura

import java.util.Hashtable;

class GrupoUnidades {
	String unidadBase;
	Hashtable unidades;
	
	public GrupoUnidades (String unidadBase) {
		this.unidadBase = unidadBase;
		this.unidades = new Hashtable();
	}
}